import React from 'react'

export default function Page404() {
  return (
    <div>Page404</div>
  )
}
